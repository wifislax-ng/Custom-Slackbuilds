#ifndef UTILS_FILE_H
#define UTILS_FILE_H

char *gettempfilename(void);
void writefile(const char* fn, const char* contents);

#endif
