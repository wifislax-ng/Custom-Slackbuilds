#ifndef HAVE_DEBUG_H
#define HAVE_DEBUG_H

void print_packet(unsigned char *h80211, int caplen);

#endif
