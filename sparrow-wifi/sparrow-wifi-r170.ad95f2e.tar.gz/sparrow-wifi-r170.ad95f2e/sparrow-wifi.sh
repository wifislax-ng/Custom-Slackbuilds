#!/bin/bash

pkexec /opt/sparrow-wifi/sparrow-wifi.py
